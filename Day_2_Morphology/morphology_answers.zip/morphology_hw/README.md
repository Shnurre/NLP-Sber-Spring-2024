# POS-Tagger

Simple POS-Tagger based on BiLSTM.

## Requirements

Download pretrained word embeddings from [here](http://vectors.nlpl.eu/repository/11/180.zip), place them in the `data` folder and unzip the archive.